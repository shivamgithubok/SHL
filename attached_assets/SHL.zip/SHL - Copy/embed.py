import os
import logging
import numpy as np
import pandas as pd
import faiss
from typing import List, Optional
import google.generativeai as genai
from google.generativeai import types
from tenacity import retry, stop_after_attempt, wait_exponential

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class EmbeddingGenerator:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("GOOGLE_API_KEY")
        self.index = None  # FAISS index
        self.data_mapping = []  # Maps FAISS index positions to text/meta
        if not self.api_key:
            logging.warning("No Google API key found.")
            self.client = None
        else:
            try:
                genai.configure(api_key=self.api_key)
                self.client = genai
                logging.info("Successfully initialized Gemini embedding client")
            except Exception as e:
                logging.error(f"Error initializing Gemini client: {e}")
                self.client = None

    def chunk_text(self, text: str, max_length: int = 500, overlap: int = 50) -> List[str]:
        """Chunk large text into smaller overlapping pieces."""
        chunks = []
        start = 0
        while start < len(text):
            end = min(len(text), start + max_length)
            chunks.append(text[start:end])
            start += max_length - overlap
        return chunks

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def generate_embedding(self, text: str) -> Optional[List[float]]:
        if not self.client:
            logging.error("Embedding client not available.")
            return None

        if not text or text.strip() == "":
            logging.warning("Empty text provided for embedding generation")
            return None

        try:
            result = self.client.embed_content(
                model="models/text-embedding-004",
                content=text
            )
            embedding = result["embedding"]
            return embedding
        except Exception as e:
            logging.error(f"Error generating embedding: {e}")
            raise

    def generate_embeddings_for_assessments(self, df: pd.DataFrame) -> pd.DataFrame:
        if not self.client:
            logging.error("Embedding client not initialized.")
            return df

        result_df = df.copy()
        result_df['embedding'] = None
        embeddings_list = []

        for idx, row in result_df.iterrows():
            full_text = f"{row['name']} - {row['description']}"
            if not full_text.strip():
                logging.warning(f"Empty text at index {idx}")
                continue

            chunks = self.chunk_text(full_text)
            for i, chunk in enumerate(chunks):
                try:
                    embedding = self.generate_embedding(chunk)
                    if embedding:
                        embeddings_list.append(np.array(embedding, dtype='float32'))
                        self.data_mapping.append((idx, row['name'], row['description'], i))  # add chunk index
                        logging.info(f"Generated embedding for chunk {i} of: {row['name']}")
                    else:
                        logging.warning(f"Failed to generate embedding for chunk {i} of: {row['name']}")
                except Exception as e:
                    logging.error(f"Exception for chunk {i} of {row['name']}: {e}")

        # Build FAISS index
        if embeddings_list:
            dimension = len(embeddings_list[0])
            self.index = faiss.IndexFlatL2(dimension)
            self.index.add(np.vstack(embeddings_list))
            logging.info("FAISS index built with chunked embeddings")

        return result_df

    def search_similar(self, query: str, top_k: int = 5):
        if not self.index:
            logging.warning("FAISS index is empty.")
            return []

        embedding = self.generate_embedding(query)
        if embedding is None:
            return []

        embedding_np = np.array(embedding, dtype='float32').reshape(1, -1)
        distances, indices = self.index.search(embedding_np, top_k)

        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self.data_mapping):
                data = self.data_mapping[idx]
                results.append({
                    'index': data[0],
                    'name': data[1],
                    'description': data[2],
                    'chunk': data[3],
                    'distance': float(dist)
                })
        return results

if __name__ == "__main__":
    generator = EmbeddingGenerator(api_key='your-google-api-key-here')

    # Example dummy DataFrame
    df = pd.DataFrame({
        'name': ['Assessment A', 'Assessment B'],
        'description': ['This is a test of AI.', 'This is a test of embeddings.']
    })

    df_with_embeddings = generator.generate_embeddings_for_assessments(df)

    # Perform similarity search
    query = "AI test"
    results = generator.search_similar(query, top_k=2)

    for res in results:
        print(f"Matched '{res['name']}' (chunk {res['chunk']}) with distance {res['distance']:.4f}")
