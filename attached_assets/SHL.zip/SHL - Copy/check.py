import streamlit as st

st.title("Test Streamlit App")
st.write("This is a test to check if Streamlit is working properly.")
