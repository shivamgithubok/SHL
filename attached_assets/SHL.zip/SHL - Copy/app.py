import streamlit as st
import pandas as pd
import logging
from embed import EmbeddingGenerator
from recommender import AssessmentRecommender

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Title and Description
st.set_page_config(page_title="Assessment Recommender", layout="wide")
st.title("🔍 Assessment Recommender")
st.markdown("Enter your text below to get assessment recommendations using AI-powered embeddings.")

# Input form
with st.form("recommendation_form"):
    user_input = st.text_area("Input Text", placeholder="Enter a description or topic...", height=200)
    top_n = st.slider("Number of Recommendations", min_value=1, max_value=20, value=5)
    submit = st.form_submit_button("Get Recommendations")

# On form submission
if submit:
    if len(user_input.strip()) < 10:
        st.warning("❗ Please enter at least 10 characters.")
    else:
        try:
            recommender = AssessmentRecommender()
            results = recommender.recommend(user_input, top_n)

            if results:
                st.success(f"Top {len(results)} recommendations for your input:")
                for i, res in enumerate(results, 1):
                    st.markdown(f"**{i}. {res['name']}**")
                    st.markdown(f"{res['description']}")
                    st.markdown("---")
            else:
                st.info("No recommendations found.")
        except Exception as e:
            logging.error(f"Recommendation error: {e}")
            st.error("⚠️ Failed to get recommendations. Please try again.")
