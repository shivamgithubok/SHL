# SHL_assesment
## all the required library's are in the pyproject.toml
## here the data is added after embedding in tradesional databasae WE can replace with FAISS and COMADB anf other to.
## here i used GOOGLE gemini api and 
## there embedding model since it is best avaliable as it free 
## api.py in interface is based on fasstapi interface
#  Scraping used to scrape relevent paper or assement accroding to the Desccription and need
# app.py
## can run the interface on the stremilit 
### run the command "Streamlit run app.py"
#   S H L _ O K  
 