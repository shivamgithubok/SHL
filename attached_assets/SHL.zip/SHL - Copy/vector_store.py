import faiss
import numpy as np
import pandas as pd
from typing import List, Dict, Any
import json
import os

class AssessmentIndex:
    def __init__(self, embedding_generator, embedding_dim: int = 768):
        self.embedding_generator = embedding_generator
        self.embedding_dim = embedding_dim
        self.index = faiss.IndexFlatL2(embedding_dim)
        self.assessments: List[Dict[str, Any]] = []

    def load_from_csv(self, csv_path: str):
        """Load assessments from a CSV file and build FAISS index."""
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"{csv_path} not found")

        df = pd.read_csv(csv_path)
        df = df[df['embedding'].notna()]
        df.reset_index(drop=True, inplace=True)

        embeddings = []
        self.assessments = []

        for _, row in df.iterrows():
            emb = json.loads(row['embedding']) if isinstance(row['embedding'], str) else row['embedding']
            emb_np = np.array(emb, dtype=np.float32)
            if emb_np.shape[0] != self.embedding_dim:
                continue
            embeddings.append(emb_np)
            self.assessments.append(row.to_dict())

        if embeddings:
            embeddings_matrix = np.stack(embeddings)
            self.index.add(embeddings_matrix)

    def search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """Return top_k most similar assessments based on query."""
        query_emb = self.embedding_generator.generate_embedding_for_query(query)
        if not query_emb:
            return []

        query_np = np.array(query_emb, dtype=np.float32).reshape(1, -1)

        if not self.index.is_trained or self.index.ntotal == 0:
            return []

        distances, indices = self.index.search(query_np, top_k)
        results = []

        for dist, idx in zip(distances[0], indices[0]):
            if 0 <= idx < len(self.assessments):
                item = self.assessments[idx].copy()
                item["similarity_score"] = float(1 / (1 + dist))  # Convert L2 distance to similarity
                results.append(item)

        return results
