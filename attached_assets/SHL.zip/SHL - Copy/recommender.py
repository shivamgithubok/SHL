import os
import numpy as np
import pandas as pd
from typing import List, Dict, Any
import logging
from dotenv import load_dotenv
from embed import EmbeddingGenerator
from vector_store import AssessmentIndex  # FAISS-based index

# Load environment variables from .env file
load_dotenv()

# Get the Google API key
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    logging.warning("No Google API key found. Please set GOOGLE_API_KEY in the .env file")

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class AssessmentRecommender:
    def __init__(self, csv_path: str = "assessments.csv"):
        self.embedding_generator = EmbeddingGenerator(api_key=GOOGLE_API_KEY)
        self.index = AssessmentIndex(embedding_generator=self.embedding_generator)
        self.index.load_from_csv(csv_path)

    def recommend(self, query: str, top_n: int = 10) -> List[Dict[str, Any]]:
        """Generate top-N assessment recommendations based on similarity to the query."""
        return self.index.search(query, top_k=top_n)

    def refresh_data(self, csv_path: str = "assessments.csv"):
        """Reload assessments and regenerate the index."""
        self.index.load_from_csv(csv_path)


if __name__ == "__main__":
    recommender = AssessmentRecommender()
    test_query = "Looking for a cognitive ability assessment for software developers"
    recommendations = recommender.recommend(test_query)

    print(f"\nTop recommendations for query: '{test_query}'")
    for i, rec in enumerate(recommendations):
        print(f"{i+1}. {rec['name']} (Score: {rec['similarity_score']:.4f})")
        print(f"   Type: {rec['test_type']}, Duration: {rec['duration']}")
        print(f"   URL: {rec['url']}")
        print()